/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sschmidt <sschmidt@student.42berlin.d      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/08 20:47:37 by sschmidt          #+#    #+#             */
/*   Updated: 2025/03/08 20:47:39 by sschmidt         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "include/print_str.h"
#include "include/ft_atoi.h"
#include "include/str_length.h"
#include "include/constants.h"
#include "include/lookupnumber.h"
#include "include/validation.h"

void printing(int hundreds, int tens, int units)
{
    if (hundreds > 0) {
        printf("%s hundred ", lookup_number(hundreds, 0));
    }
    if (tens == 1) {
        int ten_v = (tens * 10) + units;
        print_str(lookup_number(ten_v, 0));
    } else {
        if (tens > 0) {
             printf("%s ", lookup_number(tens * 10, 0));
        }
        if (units > 0) {
            printf("%s ", lookup_number(units, 0));
        }
    }


}

void process_three_digits(char *num_str) {
    int len = ft_strlen(num_str);

    if (len > 0) {
        int hundreds = 0;
        int tens = 0;
        int units = 0;

        if (len == 3) {
            hundreds = num_str[0] - '0';
            tens = num_str[1] - '0';
            units = num_str[2] - '0';
        } else if (len == 2) {
            tens = num_str[0] - '0';
            units = num_str[1] - '0';
        } else if (len == 1) {
            units = num_str[0] - '0';
        }

        printing(hundreds, tens, units);
    }
}

void print_group_word(char *str, int group_index) {
    process_three_digits(str);

    if (group_index > 0 && ft_atoi(str) != 0) {
        printf(" %s", numbers[group_index + 28].word);
    }
}

void print_number_word(char *str) {
    int len = ft_strlen(str);
    int group_count = (len - 1) / 3;
    int remaining_digits = len % 3;

    if (remaining_digits == 0 && len > 0) {
        remaining_digits = 3;
    }

    char temp[4];
    strncpy(temp, str, remaining_digits);
    temp[remaining_digits] = '\0';
    print_group_word(temp, group_count);

    int start = remaining_digits;
    int i = group_count - 1;
    while (i >= 0) {
        if (start < len) {
            strncpy(temp, str + start, 3);
            temp[3] = '\0';
            int currentNumber = ft_atoi(temp);
            if (currentNumber != 0 || i == 0) {
                printf(" ");
                print_group_word(temp, i);
            }
            start += 3;
        }
        i--;
    }
    printf("\n");
}

int main(int argc, char *argv[]) {
    
    if (argc == 2) {
     if(!is_valid_number(argv[1])) {
        printf("ERROR %s",argv[0]);
    }   else {
     print_number_word(clean_number_string(argv[1]));
    }
}
    return 0;
}
