void printing(int hundreds, int tens, int units)
{
    if (hundreds > 0) {
        printf("%s hundred ", lookup_number(hundreds, 0));
    }
    if (tens == 1) {
        int ten_v = (tens * 10) + units;
        print_str(lookup_number(ten_v, 0));
    } else {
        if (tens > 0) {
             printf("%s ", lookup_number(tens * 10, 0));
        }
        if (units > 0) {
            printf("%s ", lookup_number(units, 0));
        }
    }
}

void process_three_digits(char *num_str) {
    int len = ft_strlen(num_str);

    if (len > 0) {
        int hundreds = 0;
        int tens = 0;
        int units = 0;

        if (len == 3) {
            hundreds = num_str[0] - '0';
            tens = num_str[1] - '0';
            units = num_str[2] - '0';
        } else if (len == 2) {
            tens = num_str[0] - '0';
            units = num_str[1] - '0';
        } else if (len == 1) {
            units = num_str[0] - '0';
        }

        printing(hundreds, tens, units);
    }
}
