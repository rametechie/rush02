typedef struct {
    char *number_str;
    char *word;
    int type; // 0 for small, 1 for large
} NumberEntry;

NumberEntry numbers[] = {
    {"0", "zero", 0}, {"1", "one", 0}, {"2", "two", 0}, {"3", "three", 0}, {"4", "four", 0},
    {"5", "five", 0}, {"6", "six", 0}, {"7", "seven", 0}, {"8", "eight", 0}, {"9", "nine", 0},
    {"10", "ten", 0}, {"11", "eleven", 0}, {"12", "twelve", 0}, {"13", "thirteen", 0},
    {"14", "fourteen", 0}, {"15", "fifteen", 0}, {"16", "sixteen", 0}, {"17", "seventeen", 0},
    {"18", "eighteen", 0}, {"19", "nineteen", 0}, {"20", "twenty", 0}, {"30", "thirty", 0},
    {"40", "forty", 0}, {"50", "fifty", 0}, {"60", "sixty", 0}, {"70", "seventy", 0},
    {"80", "eighty", 0}, {"90", "ninety", 0},
    {"100", "hundred", 1},
    {"1000", "thousand", 1},
    {"1000000", "million", 1},
    {"1000000000", "billion", 1},
    {"1000000000000", "trillion", 1},
    {"1000000000000000", "quadrillion", 1},
    {"1000000000000000000", "quintillion", 1},
    {"1000000000000000000000", "sextillion", 1},
    {"1000000000000000000000000", "septillion", 1},
    {"1000000000000000000000000000", "octillion", 1},
    {"1000000000000000000000000000000", "nonillion", 1},
    {"1000000000000000000000000000000000", "decillion", 1},
    {"1000000000000000000000000000000000000", "undecillion", 1}
};
