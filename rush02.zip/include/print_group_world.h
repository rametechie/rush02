#include "include/process_three_digits.h"

void print_group_word(char *str, int group_index) {
    process_three_digits(str);

    if (group_index > 0 && ft_atoi(str) != 0) {
        printf(" %s", numbers[group_index + 28].word);
    }
}

void process_first_group(char *str, int remaining_digits, int group_count) {
    char temp[4];

    strncpy(temp, str, remaining_digits);
    temp[remaining_digits] = '\0';
    print_group_word(temp, group_count);
}

void process_group(char *str, int start, int group_index, int len) {
    char temp[4];
    int current_number;

    if (start < len) {
        strncpy(temp, str + start, 3);
        temp[3] = '\0';
        current_number = ft_atoi(temp);
        if (current_number != 0 || group_index == 0) {
            printf(" ");
            print_group_word(temp, group_index);
        }
    }
}

void process_remaining_groups(char *str, int start, int group_count, int len) {
    int i = group_count - 1;

    while (i >= 0) {
        process_group(str, start, i, len);
        start += 3;
        i--;
    }
}

void print_number_word(char *str) {
    int len;
    int group_count;
    int remaining_digits;

    len = ft_strlen(str);
    group_count = (len - 1) / 3;
    remaining_digits = len % 3;
    if (remaining_digits == 0 && len > 0)
        remaining_digits = 3;
    process_first_group(str, remaining_digits, group_count);
    process_remaining_groups(str, remaining_digits, group_count, len);
    printf("\n");
}
