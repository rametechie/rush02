#define NUMBERS_SIZE (sizeof(numbers) / sizeof(numbers[0]))

char *lookup_number(int num, int type) {
    long unsigned i = 0;
    while (i < NUMBERS_SIZE) {
        if (ft_atoi(numbers[i].number_str) == num && numbers[i].type == type) {
            return numbers[i].word;
        }
        i++;
    }
    return NULL;
}

char *lookup_large_number(int len) {
    if (len == 3) {
        return lookup_number(100, 1);
    }
    long unsigned index = (len - 1) / 3;
    if (index >= 1 && index < NUMBERS_SIZE) {
        return numbers[index + 28].word;
    }
    return NULL;
}
