/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validation.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sschmidt <sschmidt@student.42berlin.d      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/09 12:37:50 by sschmidt          #+#    #+#             */
/*   Updated: 2025/03/09 12:37:52 by sschmidt         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

#define MAX_DIGITS 37

int	isdigit_custom(char c)
{
	return (c >= '0' && c <= '9');
}

int	skip_spaces_and_remove_zeros(char *str, int i)
{
	while (str[i] == ' ')
		i++;
	if (str[i] == '+')
		i++;
	while (str[i] == '0')
		i++;
	return (i);
}

int	has_invalid_characters(char *str, int i)
{
	int	j;

	j = i;
	while (str[j] != '\0')
	{
		if (!isdigit_custom(str[j]))
			return (1);
		j++;
	}
	return (0);
}

int	is_valid_number(char *str)
{
	int	i;

	if (str == NULL || strlen(str) == 0)
		return (0);
	i = 0;
	i = skip_spaces_and_remove_zeros(str, i);
	if (str[i] == '\0' && i != 0)
	{
		strcpy(str, "0");
		return (1);
	}
	if (has_invalid_characters(str, i))
		return (0);
	if (strlen(str + i) >= MAX_DIGITS)
		return (0);
	if (i != 0)
		memmove(str, str + i, strlen(str + i) + 1);
	return (1);
}

char	*clean_number_string(char *str)
{
	if (is_valid_number(str))
		return (str);
	else
		return ("Error\n");
}
/*
int main(int argc, char **argv) {
    if (argc > 1) {
        char *result = clean_number_string(argv[1]);
        printf("%s", result);
    } else {
        printf("Usage: %s <number>\n", argv[0]);
    }
    return 0;
}
//*/